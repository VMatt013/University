package tvshow;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;

public class EpisodeManagerImpl implements EpisodeManager {
    @Override
    public boolean isTheRuntimeOfEachFirstEpisode60() {
        return getEpisodes().stream().
                filter(episode -> episode.season() == 1).
                allMatch(episode -> episode.runtime() == 60);
    }

    @Override
    public Optional<String> getLongestTitleThatContainsEwing() {
        return Optional.empty();
    }

    @Override
    public List<DayOfWeek> getDifferentAirDaysOfSeason(int season) {
        return null;
    }

    @Override
    public OptionalDouble getMaxRating() {
        return getEpisodes().stream().
                filter(episode -> episode.season() == 1).
                mapToDouble(Episode::rating).
                max();
    }

//    public void text(){
//        getEpisodes().stream().filter(episode -> episode.season() == 1).
//                forEach(System.out::println);
//    }

    public static void main(String[] args) {
        EpisodeManagerImpl episodeManager = new EpisodeManagerImpl();
        System.out.println(episodeManager.isTheRuntimeOfEachFirstEpisode60());
//        episodeManager.text();
//        System.out.println(episodeManager.getMaxRating());
    }
}
