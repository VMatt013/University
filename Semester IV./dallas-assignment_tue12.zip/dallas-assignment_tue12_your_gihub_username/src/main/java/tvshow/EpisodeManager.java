package tvshow;

import java.io.ObjectInputStream;
import java.time.DayOfWeek;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;

public interface EpisodeManager {

    @SuppressWarnings("unchecked")
    default List<Episode> getEpisodes() {
        try {
            var episodes = (List<Episode>) new ObjectInputStream(EpisodeManager.class.getResourceAsStream("dallas.ser"))
                    .readObject();
            return episodes;
        } catch (Exception e) {
            throw new AssertionError("Failed to load objects");
        }
    }

    /**
     * {@return whether the runtime of the first episode for all seasons is 60}
     */
    boolean isTheRuntimeOfEachFirstEpisode60();

    /**
     * Returns the longest episode title that contains the name <i>Ewing</i>.
     *
     * @return an {@link Optional} describing the longest episode title that
     * contains the name <i>Ewing</i>, or an empty {@link Optional} if there is
     * no such title
     */
    Optional<String> getLongestTitleThatContainsEwing();

    /**
     * {@return the list of all the different days of the week on which the
     * episodes of the given season were aired}
     *
     * @param season a season number
     */
    List<DayOfWeek> getDifferentAirDaysOfSeason(int season);

    /**
     * Returns the maximum rating of the episodes.
     *
     * @return an {@link OptionalDouble} describing the maximum rating of the
     * episodes, or an empty {@link OptionalDouble} if there are no ratings
     */
    OptionalDouble getMaxRating();

}
